Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/displayio_ssd1306_simpletest.py
    :caption: examples/displayio_ssd1306_simpletest.py
    :linenos:
