/*******************************************

This code imports the necessary modules and initializes NeoPixel rings 
connected to specific pins on a microcontroller. It defines functions 
to generate rainbow colors and display various effects on the NeoPixel rings.
 The main loop continuously executes two functions: "rainbow_chase" on ring1
  and "ring_chase" on ring2. The "rainbow_chase" function creates a rainbow 
  chasing effect on ring1, while the "ring_chase" function creates a ring 
  chasing effect on ring2 in either clockwise or 
anticlockwise direction.

by arvind patil 24 may2023





**************************************************/




import machine
import neopixel
import time

# Define the number of LEDs in each ring
NUM_LEDS_RING1 = 16
NUM_LEDS_RING2 = 16

# Define the pin to which the NeoPixel rings are connected
PIN_RING1 = 12
PIN_RING2 = 14

# Initialize the NeoPixel objects for each ring
ring1 = neopixel.NeoPixel(machine.Pin(PIN_RING1), NUM_LEDS_RING1)
ring2 = neopixel.NeoPixel(machine.Pin(PIN_RING2), NUM_LEDS_RING2)

# Define a function to generate a rainbow color
def wheel(pos):
    # Input a value 0 to 255 to get a color value.
    # The colours are a transition r - g - b - back to r.
    if pos < 0 or pos > 255:
        r, g, b = 0, 0, 0
    elif pos < 85:
        r, g, b = pos * 3, 255 - pos * 3, 0
    elif pos < 170:
        pos -= 85
        r, g, b = 255 - pos * 3, 0, pos * 3
    else:
        pos -= 170
        r, g, b = pos * 3, 0, 255 - pos * 3
    return (r, g, b)

# Define a function to display a rainbow chasing effect on a NeoPixel ring
def rainbow_chase(ring):
    for i in range(256):
        for j in range(len(ring)):
            idx = int((j * 256 / len(ring)) + i)
            ring[j] = wheel(idx & 255)
        ring.write()
        time.sleep(0.02)

# Define a function to display a ring chasing effect on a NeoPixel ring
def ring_chase(ring, direction):
    if direction == "clockwise":
        for i in range(len(ring)):
            ring[i] = (255, 0, 0)
            ring.write()
            time.sleep(0.1)
            ring[i] = (0, 0, 0)
    elif direction == "anticlockwise":
        for i in range(len(ring)):
            ring[len(ring)-1-i] = (0, 255, 0)
            ring.write()
            time.sleep(0.1)
            ring[len(ring)-1-i] = (0, 0, 150)

# Main loop
while True:
    rainbow_chase(ring1)
    ring_chase(ring2, "anticlockwise")
